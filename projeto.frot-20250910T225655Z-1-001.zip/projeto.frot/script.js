// Projetos iniciais com categorias e link externo
const projetos = [
  {
    id: 1,
    titulo: "App de Tarefas",
    descricao: "Gerencie suas tarefas diárias com uma interface limpa e intuitiva.",
    imagem: "https://images.unsplash.com/photo-1515377905703-c4788e51af15?auto=format&fit=crop&w=800&q=80",
    categoria: "web",
    link: "https://github.com/usuario/app-tarefas"
  },
  {
    id: 2,
    titulo: "Portfólio Pessoal",
    descricao: "Site responsivo para mostrar meus trabalhos e experiências.",
    imagem: "https://images.unsplash.com/photo-1504384308090-c894fdcc538d?auto=format&fit=crop&w=800&q=80",
    categoria: "web",
    link: "https://meuportfolio.com"
  },
  {
    id: 3,
    titulo: "Blog de Tecnologia",
    descricao: "Compartilhando artigos e novidades do mundo tech.",
    imagem: "https://images.unsplash.com/photo-1519389950473-47ba0277781c?auto=format&fit=crop&w=800&q=80",
    categoria: "web",
    link: "https://blogdetecnologia.com"
  },
  {
    id: 4,
    titulo: "Loja Online",
    descricao: "E-commerce moderno com sistema de pagamentos integrado.",
    imagem: "https://images.unsplash.com/photo-1522202176988-66273c2fd55f?auto=format&fit=crop&w=800&q=80",
    categoria: "web",
    link: "https://lojavirtual.com"
  },
  {
    id: 5,
    titulo: "Dashboard Financeiro",
    descricao: "Visualize suas finanças com gráficos interativos e análises detalhadas.",
    imagem: "https://images.unsplash.com/photo-1498050108023-c5249f4df085?auto=format&fit=crop&w=800&q=80",
    categoria: "web",
    link: "https://financeiroapp.com"
  },
  {
    id: 6,
    titulo: "Jogo Multiplayer",
    descricao: "Jogo online em tempo real com rankings e conquistas.",
    imagem: "https://images.unsplash.com/photo-1511512578047-dfb367046420?auto=format&fit=crop&w=800&q=80",
    categoria: "game",
    link: "https://jogoonline.com"
  },
  {
    id: 7,
    titulo: "App Mobile Fitness",
    descricao: "Aplicativo para acompanhar treinos e progresso físico.",
    imagem: "https://images.unsplash.com/photo-1557804506-669a67965ba0?auto=format&fit=crop&w=800&q=80",
    categoria: "mobile",
    link: "https://appfitness.com"
  },
  {
    id: 8,
    titulo: "App de Meditação",
    descricao: "Relaxe e melhore seu foco com sessões guiadas.",
    imagem: "https://images.unsplash.com/photo-1506744038136-46273834b3fb?auto=format&fit=crop&w=800&q=80",
    categoria: "mobile",
    link: "https://appmeditacao.com"
  }
];

// Controle do número de projetos exibidos
let projetosVisiveis = 4;

// Referências DOM
const projectsGrid = document.getElementById('projectsGrid');
const loadMoreBtn = document.getElementById('loadMoreBtn')
